[![built-with-azurra-framework](https://github.com/B00merang-Project/Azurra_framework/raw/assets/azurra_framework_smaller.png)](https://github.com/B00merang-Project/Azurra_framework)

# Windows 10 Fluent Dark
GTK theme based on the appearance of Microsoft's latest design guidelines, dark version

### Preview
![acrylic-dark](https://github.com/B00merang-Project/gallery/raw/master/Windows%2010%20Acrylic%20Dark%20(3).png)

### Supported platforms
- Any GTK-based desktop
- Cinnamon
- Gnome
- LXDE/Openbox
- MATE
- Xfce

### Manual installation
Go to releases, download the latest `.zip` file and extract it to the themes directory i.e. `/home/USERNAME/.themes`
